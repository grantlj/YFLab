package com.yflab.model;

public class Infrared {
  private int id;
  private String state,arg0,arg1;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getState() {
	return state;
}
public void setState(String state) {
	this.state = state;
}
public String getArg0() {
	return arg0;
}
public void setArg0(String arg0) {
	this.arg0 = arg0;
}
public String getArg1() {
	return arg1;
}
public void setArg1(String arg1) {
	this.arg1 = arg1;
}
  
}
